<div class='single-message'>
    <h5>{{ $message->fromUser->name }}</h5>
    <p>{{ $message->text }}</p>
</div>