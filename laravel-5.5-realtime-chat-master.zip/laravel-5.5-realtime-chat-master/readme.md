# Realtime Chat using Laravel 5.5, Pusher and Echo

I used Laravel's broadcasting feature.

## How to make this work?

- Create `.env` file and fill values for your pusher app account.

## Donate

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Q4XLBV46V3958)
