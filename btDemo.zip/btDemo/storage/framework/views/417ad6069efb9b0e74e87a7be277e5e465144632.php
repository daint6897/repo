<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-inverse">
            <thead>
                <tr>
                    <th>Ten user</th>
                    <th>dia chi</th>
                    <th>So dien thoai</th>
                    <th>Loai user</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $dataUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value['name']); ?></td>
                        <td><?php echo e($value['diaChi']); ?></td>
                        <td><?php echo e($value['soDienThoai']); ?></td>
                        <td>
                            <?php if($value['level'] ==1): ?>
                                <?php echo e("User"); ?>

                            <?php endif; ?>
                            <?php if($value['level'] ==2): ?>
                                <?php echo e("Nguoi Ban"); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                        <form action="<?php echo e(route('quanLyUserDestroy',[$value['id']])); ?>" method="POST">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="submit" value="Xoa">
                        </form>
                        </td>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>