<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <form action="<?php echo e(route('sanPham.update',[$item->id])); ?>" method="POST">
          <input type="hidden" name="_method" value="PATCH">
                    <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label>Ten san pham</label>
                    <input type="text" class="form-control" name="tenSanPham" value="<?php echo e($item->tenSanPham); ?>">
                  </div>
                  <div class="form-group">
                    <label>Chi tiet san pham</label>
                    <input type="text" class="form-control" name="chiTiet" value="<?php echo e($item->chiTiet); ?>">
                  </div>

                  <div class="form-group">
                    <label>so luong</label>
                    <input type="text" class="form-control" name="soLuong" value="<?php echo e($item->soLuong); ?>">
                  </div>

                  <div class="form-group hidden">
                    <label>id nguoi ban</label>
                    <input type="text" class="form-control" name="idNguoiBan" value="<?php echo e(Auth::user()->id); ?>">
                  </div>
                  <div class="form-group hidden">
                    <input type="text" name="image" required="true" value="<?php echo e($item->image); ?>">
                  </div>
                  <button type="submit" class="btn btn-primary">Cap nhat pham</button>
                </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>