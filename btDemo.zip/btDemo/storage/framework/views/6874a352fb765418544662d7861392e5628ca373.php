<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-inverse">
            <thead>
                <tr>
                    <th>Ten san pham</th>
                    <th>Anh</th>
                    <th>Sua</th>
                    <th>Xoa</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $dataSanPham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value['tenSanPham']); ?></td>
                        <td><img src=<?php echo e(asset($value['image'])); ?> class="img-thumbnail anh"  alt="image"></td>
                        <td><a href="<?php echo e(route('sanPham.edit', ['idSanPham' =>$value["id"] ])); ?>"><button type="button" class="btn btn-primary">Sua</button></a></td>
                        <td>
                        <form action="<?php echo e(route('sanPham.destroy',[$value['id']])); ?>" method="POST">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="submit" value="Xoa">
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>