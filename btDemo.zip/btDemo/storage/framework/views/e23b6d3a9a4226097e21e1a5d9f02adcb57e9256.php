<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-inverse">
            <thead>
                <tr>
                    <th>Ten san pham</th>
                    <th>Anh</th>
                    <th>Nguoi mua hang</th>
                    <th>Dia chi</th>
                    <th>So dien thoai</th>
                    <th>Giao Hang</th>
                    <th>Ko Giao Hang</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $dataSanPhamPheDuyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value['tenSanPham']); ?></td>
                        <td><img src=<?php echo e(asset($value['image'])); ?> class="img-thumbnail anh"  alt="image"></td>
                        <td><?php echo e($value['tenUser']); ?></td>
                        <td><?php echo e($value['diaChi']); ?></td>
                        <td><?php echo e($value['soDienThoai']); ?></td>
                        <td><a href="<?php echo e(route('nguoiBanPheDuyetSanPham', ['idSanPham' =>$value["idSanPham"] ])); ?>"><button type="button" class="btn btn-primary">Giao Hang</button></a></td>
                        <td><a href="<?php echo e(route('nguoiBanXoaPheDuyetSanPham', ['idSanPham' =>$value["idSanPham"] ])); ?>"><button type="button" class="btn btn-primary">xoa</button></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>