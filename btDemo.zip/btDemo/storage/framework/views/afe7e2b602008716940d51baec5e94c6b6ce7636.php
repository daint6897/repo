<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    	<?php $__currentLoopData = $dataSanPhamChiTiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	   <div class="card">
				<div class="container-fliud">
					<div class="wrapper row">
						<div class="preview col-md-6">
							  <div class="img-fluid" id="pic-1"><img class="img-fluid anhChiTiet" src="<?php echo e($value->image); ?>" /></div>
						</div>
						<div class="details col-md-6">
							<h3 class="product-title"><?php echo e($value->tenSanPham); ?></h3>
							<p class="product-description"><?php echo e($value->chiTiet); ?></p>
							<h4 class="price">Gia: <span><?php echo e(number_format($value->gia)); ?> VND</span></h4>
							<p class="vote"><strong>Duoc ban boi</strong> <strong> : <?php echo e($value->name); ?></strong></p>
							<div class="action">
								<a href="<?php echo e(route('muaHangg',$value->id)); ?>" class="btn btn-primary">mua hang</a>
							</div>
						</div>
					</div>
				</div>
			</div>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>