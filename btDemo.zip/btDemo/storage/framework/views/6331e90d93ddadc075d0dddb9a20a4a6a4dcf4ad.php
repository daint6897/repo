<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-inverse">
            <thead>
                <tr>
                    <th>Ten san pham</th>
                    <th>Anh</th>
                    <th>Phe duyet</th>
                    <th>Ko phe duyet</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $dataSanPhamPheDuyet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value['tenSanPham']); ?></td>
                        <td><img src=<?php echo e(asset($value['image'])); ?> class="img-thumbnail anh"  alt="image"></td>
                        <td><a href="<?php echo e(route('adminPheDuyetSanPham', ['idSanPham' =>$value["id"] ])); ?>"><button type="button" class="btn btn-primary">phe duyet</button></a></td>
                        <td><a href="<?php echo e(route('adminXoaPheDuyetSanPham', ['idSanPham' =>$value["id"] ])); ?>"><button type="button" class="btn btn-primary">xoa</button></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>