<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>BTdemo</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?> " />
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        BTdemo
                    </a>
                </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>
                                        <a href="<?php echo e(route('suaUser',Auth::user()->id)); ?>">
                                            Sua thong tin
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                                <ul>
                                    <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Thong Bao
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <?php $__currentLoopData = $dataThongBao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(Auth::user()->level ==3 && $value['idAdmin']==1): ?>
                                                <p>-<?php echo e($value['noiDung']); ?></p>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->level ==2 && $value['idNguoiBan']==Auth::user()->id): ?>
                                                <p>-<?php echo e($value['noiDung']); ?></p>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->level ==1 && $value['idUser']==Auth::user()->id): ?>
                                                <p>-<?php echo e($value['noiDung']); ?></p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </div>
                                    </div>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php if(Auth::check()): ?>

                  <?php if(Auth::user()->level==2): ?>
                    <div class="menuNguoiBan">
                        <ul>
                                <a href="<?php echo e(route('sanPham.create')); ?>"><button type="button" class="btn btn-primary">Them san pham</button></a>
                            </ul>
                            <ul>
                                <a href="<?php echo e(route('nguoiBanPheDuyet')); ?>"><button type="button" class="btn btn-primary">Don hang cho phe duyet</button></a>
                            </ul>
                            <ul>
                                <a href="<?php echo e(route('sanPham.index')); ?>"><button type="button" class="btn btn-primary btn-ql">Quan ly san pham</button></a>
                            </ul>
                    </div>
                    <?php endif; ?>

                <?php if(Auth::user()->level==3): ?>
                    <div class="menuNguoiBan">
                        <ul>
                                <a href="<?php echo e(route('quanLyUser')); ?>"><button type="button" class="btn btn-primary">Quan Ly user</button></a>
                            </ul>
                            <ul>
                                <a href="<?php echo e(route('quanLySanPham')); ?>"><button type="button" class="btn btn-primary">Quan Ly San Pham</button></a>
                            </ul>
                            <ul>
                                <a href="<?php echo e(route('nguoiBanPheDuyet')); ?>"><button type="button" class="btn btn-primary">Quan Ly phe duyet</button></a>
                            </ul>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
