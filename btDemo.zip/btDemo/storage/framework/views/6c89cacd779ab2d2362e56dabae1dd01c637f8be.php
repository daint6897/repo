<?php $__env->startSection('content'); ?>
<div class="container">
  <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="col-md-4 col-md-offset-4">
        <form action="<?php echo e(route('updateUser',[$value['id']])); ?>" method="POST">
          <input type="hidden" name="_method" value="PATCH">
                    <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label>Ten user</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($value['name']); ?>">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" name="email" value="<?php echo e($value['email']); ?>">
                  </div>
                  <div class="form-group">
                    <label>Dia chi</label>
                    <input type="text" class="form-control" name="diaChi" value="<?php echo e($value['diaChi']); ?>">
                  </div>
                  <div class="form-group">
                    <label>So dien thoai</label>
                    <input type="text" class="form-control" name="soDienThoai" value="<?php echo e($value['soDienThoai']); ?>">
                  </div>
                  <button type="submit" class="btn btn-primary">Cap nhat</button>
                </form>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>