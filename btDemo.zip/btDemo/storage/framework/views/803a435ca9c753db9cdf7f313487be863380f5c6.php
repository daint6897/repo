<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
                    <form action="<?php echo e(route('search')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="timKiem">
                            <input class="timKiem1" type="text" class="form-control" name="ten" placeholder="Search" >
                            <input class="timKiem2" type="submit" value="Go">
                        </div>
                    </form>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <?php if($dataSp==null): ?>
         <?php echo e("khong tim thay san pham"); ?>

        <?php endif; ?>
        <?php $__currentLoopData = $dataSp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 marginSp">
            <div class="card" style="width: 100%;">
                <a href="<?php echo e(route('chiTietSanPham',$value['id'])); ?>"><img class="card-img-top anh2" src="<?php echo e($value['image']); ?>" alt="Card image cap"></a>
              <div class="card-body">
                <h5 class="card-title">Ten :<?php echo e($value['tenSanPham']); ?></h5>
                <p class="card-text">Chi tiet:<?php echo e($value['chiTiet']); ?></p>
                <p class="card-text">Gia:
                <?php if($value['gia']==Null): ?>
                    <?php echo e("lien he"); ?>

                <?php endif; ?>
                <?php echo e(number_format($value['gia'])); ?>

                VND</p>
                
                <a href="<?php echo e(route('muaHangg',$value['id'])); ?>" class="btn btn-primary">mua hang</a>

              </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>